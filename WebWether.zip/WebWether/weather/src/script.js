import './assets/style.css'

import { createApp } from 'vue'
import Web from './Web.vue'

createApp(Web).mount('#app')
